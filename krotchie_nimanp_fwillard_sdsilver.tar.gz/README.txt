ECE574A Assignement 1:
Group Members:
  Name                NetID
  Michael Krotchie    krotchie   
  Finn Willard        fwillard
  Paul Niman          nimanp
  Sterling Davis      sdsilver

Xilinx Environment
  Vivado version: 2020.1
  Target FPGA   : xc7a100tcsg324-3

Critical Path Calculation Methodology: 
  In order to manually calculate our estimated critical paths, we first drew out
  block diagrams with synthasized latencies labeled for each block. Once the
  diagrams were complete we summed up each of the datapaths through each circuit.
  The paths that had the longest estimated delays relative to the other paths on
  the same circuit were the estimated critical paths of each respective circuit.
